--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.10 (Ubuntu 10.10-1.pgdg18.04+1)
-- Dumped by pg_dump version 10.10 (Ubuntu 10.10-1.pgdg18.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.role_has_permissions DROP CONSTRAINT role_has_permissions_role_id_foreign;
ALTER TABLE ONLY public.role_has_permissions DROP CONSTRAINT role_has_permissions_permission_id_foreign;
ALTER TABLE ONLY public.model_has_roles DROP CONSTRAINT model_has_roles_role_id_foreign;
ALTER TABLE ONLY public.model_has_permissions DROP CONSTRAINT model_has_permissions_permission_id_foreign;
DROP INDEX public.password_resets_email_index;
DROP INDEX public.model_has_roles_model_id_model_type_index;
DROP INDEX public.model_has_permissions_model_id_model_type_index;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_email_unique;
ALTER TABLE ONLY public.team DROP CONSTRAINT team_pkey;
ALTER TABLE ONLY public.supplier DROP CONSTRAINT supplier_pkey;
ALTER TABLE ONLY public.servis DROP CONSTRAINT servis_pkey;
ALTER TABLE ONLY public.roles DROP CONSTRAINT roles_pkey;
ALTER TABLE ONLY public.role_has_permissions DROP CONSTRAINT role_has_permissions_pkey;
ALTER TABLE ONLY public.project DROP CONSTRAINT project_pkey;
ALTER TABLE ONLY public.post DROP CONSTRAINT post_pkey;
ALTER TABLE ONLY public.permissions DROP CONSTRAINT permissions_pkey;
ALTER TABLE ONLY public.part DROP CONSTRAINT part_pkey;
ALTER TABLE ONLY public.part_kategori DROP CONSTRAINT part_kategori_pkey;
ALTER TABLE ONLY public.model_has_roles DROP CONSTRAINT model_has_roles_pkey;
ALTER TABLE ONLY public.model_has_permissions DROP CONSTRAINT model_has_permissions_pkey;
ALTER TABLE ONLY public.migrations DROP CONSTRAINT migrations_pkey;
ALTER TABLE ONLY public.kategori_servis DROP CONSTRAINT kategori_servis_pkey;
ALTER TABLE ONLY public.job DROP CONSTRAINT job_pkey;
ALTER TABLE ONLY public.jasa DROP CONSTRAINT jasa_pkey;
ALTER TABLE ONLY public.failed_jobs DROP CONSTRAINT failed_jobs_pkey;
ALTER TABLE ONLY public.devisi DROP CONSTRAINT devisi_pkey;
ALTER TABLE ONLY public.dept DROP CONSTRAINT dept_pkey;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.team ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.supplier ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.servis ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.roles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.project ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.post ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.part_kategori ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.part ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.migrations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.kategori_servis ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.job ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.jasa ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.failed_jobs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.devisi ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.dept ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP SEQUENCE public.team_id_seq;
DROP TABLE public.team;
DROP SEQUENCE public.supplier_id_seq;
DROP TABLE public.supplier;
DROP SEQUENCE public.servis_id_seq;
DROP TABLE public.servis;
DROP SEQUENCE public.roles_id_seq;
DROP TABLE public.roles;
DROP TABLE public.role_has_permissions;
DROP SEQUENCE public.project_id_seq;
DROP TABLE public.project;
DROP SEQUENCE public.post_id_seq;
DROP TABLE public.post;
DROP SEQUENCE public.permissions_id_seq;
DROP TABLE public.permissions;
DROP TABLE public.password_resets;
DROP SEQUENCE public.part_kategori_id_seq;
DROP TABLE public.part_kategori;
DROP SEQUENCE public.part_id_seq;
DROP TABLE public.part;
DROP TABLE public.model_has_roles;
DROP TABLE public.model_has_permissions;
DROP SEQUENCE public.migrations_id_seq;
DROP TABLE public.migrations;
DROP SEQUENCE public.kategori_servis_id_seq;
DROP TABLE public.kategori_servis;
DROP SEQUENCE public.job_id_seq;
DROP TABLE public.job;
DROP SEQUENCE public.jasa_id_seq;
DROP TABLE public.jasa;
DROP SEQUENCE public.failed_jobs_id_seq;
DROP TABLE public.failed_jobs;
DROP SEQUENCE public.devisi_id_seq;
DROP TABLE public.devisi;
DROP SEQUENCE public.dept_id_seq;
DROP TABLE public.dept;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: dept; Type: TABLE; Schema: public; Owner: laravel
--

CREATE TABLE public.dept (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    keterangan text NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.dept OWNER TO laravel;

--
-- Name: dept_id_seq; Type: SEQUENCE; Schema: public; Owner: laravel
--

CREATE SEQUENCE public.dept_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dept_id_seq OWNER TO laravel;

--
-- Name: dept_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laravel
--

ALTER SEQUENCE public.dept_id_seq OWNED BY public.dept.id;


--
-- Name: devisi; Type: TABLE; Schema: public; Owner: laravel
--

CREATE TABLE public.devisi (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    keterangan text NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.devisi OWNER TO laravel;

--
-- Name: devisi_id_seq; Type: SEQUENCE; Schema: public; Owner: laravel
--

CREATE SEQUENCE public.devisi_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.devisi_id_seq OWNER TO laravel;

--
-- Name: devisi_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laravel
--

ALTER SEQUENCE public.devisi_id_seq OWNED BY public.devisi.id;


--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: laravel
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO laravel;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: laravel
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.failed_jobs_id_seq OWNER TO laravel;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laravel
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: jasa; Type: TABLE; Schema: public; Owner: laravel
--

CREATE TABLE public.jasa (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    nama character varying(255),
    gambar character varying(255),
    deskripsi text,
    jam_support text,
    fitur text,
    benefit text,
    harga character varying(255),
    team_id integer,
    job_id integer
);


ALTER TABLE public.jasa OWNER TO laravel;

--
-- Name: jasa_id_seq; Type: SEQUENCE; Schema: public; Owner: laravel
--

CREATE SEQUENCE public.jasa_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.jasa_id_seq OWNER TO laravel;

--
-- Name: jasa_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laravel
--

ALTER SEQUENCE public.jasa_id_seq OWNED BY public.jasa.id;


--
-- Name: job; Type: TABLE; Schema: public; Owner: laravel
--

CREATE TABLE public.job (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    nama character varying(255),
    deskripsi text
);


ALTER TABLE public.job OWNER TO laravel;

--
-- Name: job_id_seq; Type: SEQUENCE; Schema: public; Owner: laravel
--

CREATE SEQUENCE public.job_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.job_id_seq OWNER TO laravel;

--
-- Name: job_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laravel
--

ALTER SEQUENCE public.job_id_seq OWNED BY public.job.id;


--
-- Name: kategori_servis; Type: TABLE; Schema: public; Owner: laravel
--

CREATE TABLE public.kategori_servis (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    name character varying(255) NOT NULL,
    keterangan text NOT NULL,
    biaya double precision NOT NULL
);


ALTER TABLE public.kategori_servis OWNER TO laravel;

--
-- Name: kategori_servis_id_seq; Type: SEQUENCE; Schema: public; Owner: laravel
--

CREATE SEQUENCE public.kategori_servis_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.kategori_servis_id_seq OWNER TO laravel;

--
-- Name: kategori_servis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laravel
--

ALTER SEQUENCE public.kategori_servis_id_seq OWNED BY public.kategori_servis.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: laravel
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO laravel;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: laravel
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO laravel;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laravel
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: model_has_permissions; Type: TABLE; Schema: public; Owner: laravel
--

CREATE TABLE public.model_has_permissions (
    permission_id integer NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id bigint NOT NULL
);


ALTER TABLE public.model_has_permissions OWNER TO laravel;

--
-- Name: model_has_roles; Type: TABLE; Schema: public; Owner: laravel
--

CREATE TABLE public.model_has_roles (
    role_id integer NOT NULL,
    model_type character varying(255) NOT NULL,
    model_id bigint NOT NULL
);


ALTER TABLE public.model_has_roles OWNER TO laravel;

--
-- Name: part; Type: TABLE; Schema: public; Owner: laravel
--

CREATE TABLE public.part (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    part_kategori_id integer,
    supplier_id integer,
    nama character varying(255),
    sku character varying(255) NOT NULL,
    barcode character varying(255) NOT NULL,
    deskripsi text,
    berat double precision DEFAULT '0'::double precision NOT NULL,
    harga_beli double precision NOT NULL,
    harga_jual double precision NOT NULL,
    stock integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.part OWNER TO laravel;

--
-- Name: part_id_seq; Type: SEQUENCE; Schema: public; Owner: laravel
--

CREATE SEQUENCE public.part_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.part_id_seq OWNER TO laravel;

--
-- Name: part_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laravel
--

ALTER SEQUENCE public.part_id_seq OWNED BY public.part.id;


--
-- Name: part_kategori; Type: TABLE; Schema: public; Owner: laravel
--

CREATE TABLE public.part_kategori (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    nama character varying(255),
    deskripsi text
);


ALTER TABLE public.part_kategori OWNER TO laravel;

--
-- Name: part_kategori_id_seq; Type: SEQUENCE; Schema: public; Owner: laravel
--

CREATE SEQUENCE public.part_kategori_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.part_kategori_id_seq OWNER TO laravel;

--
-- Name: part_kategori_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laravel
--

ALTER SEQUENCE public.part_kategori_id_seq OWNED BY public.part_kategori.id;


--
-- Name: password_resets; Type: TABLE; Schema: public; Owner: laravel
--

CREATE TABLE public.password_resets (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_resets OWNER TO laravel;

--
-- Name: permissions; Type: TABLE; Schema: public; Owner: laravel
--

CREATE TABLE public.permissions (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    guard_name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.permissions OWNER TO laravel;

--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: laravel
--

CREATE SEQUENCE public.permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.permissions_id_seq OWNER TO laravel;

--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laravel
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: post; Type: TABLE; Schema: public; Owner: laravel
--

CREATE TABLE public.post (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    tag_id integer NOT NULL,
    title character varying(255) NOT NULL,
    body text NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.post OWNER TO laravel;

--
-- Name: post_id_seq; Type: SEQUENCE; Schema: public; Owner: laravel
--

CREATE SEQUENCE public.post_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.post_id_seq OWNER TO laravel;

--
-- Name: post_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laravel
--

ALTER SEQUENCE public.post_id_seq OWNED BY public.post.id;


--
-- Name: project; Type: TABLE; Schema: public; Owner: laravel
--

CREATE TABLE public.project (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    kode_project character varying(25),
    nama character varying(255),
    deskripsi text,
    job_id integer,
    jasa_id integer,
    tgl_mulai character varying(255),
    tgl_selesai character varying(255),
    status character varying(255) DEFAULT 'rencana'::character varying NOT NULL,
    harga_penawaran double precision NOT NULL,
    harga_kesepakatan double precision NOT NULL,
    users_id integer,
    team_id integer
);


ALTER TABLE public.project OWNER TO laravel;

--
-- Name: project_id_seq; Type: SEQUENCE; Schema: public; Owner: laravel
--

CREATE SEQUENCE public.project_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.project_id_seq OWNER TO laravel;

--
-- Name: project_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laravel
--

ALTER SEQUENCE public.project_id_seq OWNED BY public.project.id;


--
-- Name: role_has_permissions; Type: TABLE; Schema: public; Owner: laravel
--

CREATE TABLE public.role_has_permissions (
    permission_id integer NOT NULL,
    role_id integer NOT NULL
);


ALTER TABLE public.role_has_permissions OWNER TO laravel;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: laravel
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    guard_name character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.roles OWNER TO laravel;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: laravel
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO laravel;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laravel
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: servis; Type: TABLE; Schema: public; Owner: laravel
--

CREATE TABLE public.servis (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    users_id integer,
    jasa_id integer,
    kode_servis character varying(25),
    merk character varying(255) NOT NULL,
    model character varying(255) NOT NULL,
    unit character varying(255) NOT NULL,
    keterangan text NOT NULL,
    kategori_servis_id integer,
    garansi_id integer,
    snid character varying(25),
    keluhan text NOT NULL,
    status character varying(255) NOT NULL,
    team_id integer
);


ALTER TABLE public.servis OWNER TO laravel;

--
-- Name: servis_id_seq; Type: SEQUENCE; Schema: public; Owner: laravel
--

CREATE SEQUENCE public.servis_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.servis_id_seq OWNER TO laravel;

--
-- Name: servis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laravel
--

ALTER SEQUENCE public.servis_id_seq OWNED BY public.servis.id;


--
-- Name: supplier; Type: TABLE; Schema: public; Owner: laravel
--

CREATE TABLE public.supplier (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    nama character varying(255),
    alamat character varying(255),
    email character varying(255),
    telepon character varying(255),
    status character varying(255) DEFAULT 'active'::character varying NOT NULL
);


ALTER TABLE public.supplier OWNER TO laravel;

--
-- Name: supplier_id_seq; Type: SEQUENCE; Schema: public; Owner: laravel
--

CREATE SEQUENCE public.supplier_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.supplier_id_seq OWNER TO laravel;

--
-- Name: supplier_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laravel
--

ALTER SEQUENCE public.supplier_id_seq OWNED BY public.supplier.id;


--
-- Name: team; Type: TABLE; Schema: public; Owner: laravel
--

CREATE TABLE public.team (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    deleted_at timestamp(0) without time zone,
    nik character varying(255),
    foto character varying(255),
    nama character varying(255),
    alamat character varying(255),
    email character varying(255),
    telepon character varying(255),
    dept_id integer NOT NULL,
    devisi_id integer NOT NULL
);


ALTER TABLE public.team OWNER TO laravel;

--
-- Name: team_id_seq; Type: SEQUENCE; Schema: public; Owner: laravel
--

CREATE SEQUENCE public.team_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.team_id_seq OWNER TO laravel;

--
-- Name: team_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laravel
--

ALTER SEQUENCE public.team_id_seq OWNED BY public.team.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: laravel
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.users OWNER TO laravel;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: laravel
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO laravel;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: laravel
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: dept id; Type: DEFAULT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.dept ALTER COLUMN id SET DEFAULT nextval('public.dept_id_seq'::regclass);


--
-- Name: devisi id; Type: DEFAULT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.devisi ALTER COLUMN id SET DEFAULT nextval('public.devisi_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: jasa id; Type: DEFAULT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.jasa ALTER COLUMN id SET DEFAULT nextval('public.jasa_id_seq'::regclass);


--
-- Name: job id; Type: DEFAULT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.job ALTER COLUMN id SET DEFAULT nextval('public.job_id_seq'::regclass);


--
-- Name: kategori_servis id; Type: DEFAULT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.kategori_servis ALTER COLUMN id SET DEFAULT nextval('public.kategori_servis_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: part id; Type: DEFAULT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.part ALTER COLUMN id SET DEFAULT nextval('public.part_id_seq'::regclass);


--
-- Name: part_kategori id; Type: DEFAULT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.part_kategori ALTER COLUMN id SET DEFAULT nextval('public.part_kategori_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: post id; Type: DEFAULT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.post ALTER COLUMN id SET DEFAULT nextval('public.post_id_seq'::regclass);


--
-- Name: project id; Type: DEFAULT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.project ALTER COLUMN id SET DEFAULT nextval('public.project_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: servis id; Type: DEFAULT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.servis ALTER COLUMN id SET DEFAULT nextval('public.servis_id_seq'::regclass);


--
-- Name: supplier id; Type: DEFAULT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.supplier ALTER COLUMN id SET DEFAULT nextval('public.supplier_id_seq'::regclass);


--
-- Name: team id; Type: DEFAULT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.team ALTER COLUMN id SET DEFAULT nextval('public.team_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: dept; Type: TABLE DATA; Schema: public; Owner: laravel
--

COPY public.dept (id, name, keterangan, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.dept (id, name, keterangan, created_at, updated_at, deleted_at) FROM '$$PATH$$/3126.dat';

--
-- Data for Name: devisi; Type: TABLE DATA; Schema: public; Owner: laravel
--

COPY public.devisi (id, name, keterangan, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.devisi (id, name, keterangan, created_at, updated_at, deleted_at) FROM '$$PATH$$/3128.dat';

--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: laravel
--

COPY public.failed_jobs (id, connection, queue, payload, exception, failed_at) FROM stdin;
\.
COPY public.failed_jobs (id, connection, queue, payload, exception, failed_at) FROM '$$PATH$$/3115.dat';

--
-- Data for Name: jasa; Type: TABLE DATA; Schema: public; Owner: laravel
--

COPY public.jasa (id, created_at, updated_at, deleted_at, nama, gambar, deskripsi, jam_support, fitur, benefit, harga, team_id, job_id) FROM stdin;
\.
COPY public.jasa (id, created_at, updated_at, deleted_at, nama, gambar, deskripsi, jam_support, fitur, benefit, harga, team_id, job_id) FROM '$$PATH$$/3136.dat';

--
-- Data for Name: job; Type: TABLE DATA; Schema: public; Owner: laravel
--

COPY public.job (id, created_at, updated_at, deleted_at, nama, deskripsi) FROM stdin;
\.
COPY public.job (id, created_at, updated_at, deleted_at, nama, deskripsi) FROM '$$PATH$$/3140.dat';

--
-- Data for Name: kategori_servis; Type: TABLE DATA; Schema: public; Owner: laravel
--

COPY public.kategori_servis (id, created_at, updated_at, deleted_at, name, keterangan, biaya) FROM stdin;
\.
COPY public.kategori_servis (id, created_at, updated_at, deleted_at, name, keterangan, biaya) FROM '$$PATH$$/3144.dat';

--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: laravel
--

COPY public.migrations (id, migration, batch) FROM stdin;
\.
COPY public.migrations (id, migration, batch) FROM '$$PATH$$/3108.dat';

--
-- Data for Name: model_has_permissions; Type: TABLE DATA; Schema: public; Owner: laravel
--

COPY public.model_has_permissions (permission_id, model_type, model_id) FROM stdin;
\.
COPY public.model_has_permissions (permission_id, model_type, model_id) FROM '$$PATH$$/3120.dat';

--
-- Data for Name: model_has_roles; Type: TABLE DATA; Schema: public; Owner: laravel
--

COPY public.model_has_roles (role_id, model_type, model_id) FROM stdin;
\.
COPY public.model_has_roles (role_id, model_type, model_id) FROM '$$PATH$$/3121.dat';

--
-- Data for Name: part; Type: TABLE DATA; Schema: public; Owner: laravel
--

COPY public.part (id, created_at, updated_at, deleted_at, part_kategori_id, supplier_id, nama, sku, barcode, deskripsi, berat, harga_beli, harga_jual, stock) FROM stdin;
\.
COPY public.part (id, created_at, updated_at, deleted_at, part_kategori_id, supplier_id, nama, sku, barcode, deskripsi, berat, harga_beli, harga_jual, stock) FROM '$$PATH$$/3132.dat';

--
-- Data for Name: part_kategori; Type: TABLE DATA; Schema: public; Owner: laravel
--

COPY public.part_kategori (id, created_at, updated_at, deleted_at, nama, deskripsi) FROM stdin;
\.
COPY public.part_kategori (id, created_at, updated_at, deleted_at, nama, deskripsi) FROM '$$PATH$$/3134.dat';

--
-- Data for Name: password_resets; Type: TABLE DATA; Schema: public; Owner: laravel
--

COPY public.password_resets (email, token, created_at) FROM stdin;
\.
COPY public.password_resets (email, token, created_at) FROM '$$PATH$$/3113.dat';

--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: laravel
--

COPY public.permissions (id, name, guard_name, created_at, updated_at) FROM stdin;
\.
COPY public.permissions (id, name, guard_name, created_at, updated_at) FROM '$$PATH$$/3117.dat';

--
-- Data for Name: post; Type: TABLE DATA; Schema: public; Owner: laravel
--

COPY public.post (id, user_id, tag_id, title, body, created_at, updated_at, deleted_at) FROM stdin;
\.
COPY public.post (id, user_id, tag_id, title, body, created_at, updated_at, deleted_at) FROM '$$PATH$$/3110.dat';

--
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: laravel
--

COPY public.project (id, created_at, updated_at, deleted_at, kode_project, nama, deskripsi, job_id, jasa_id, tgl_mulai, tgl_selesai, status, harga_penawaran, harga_kesepakatan, users_id, team_id) FROM stdin;
\.
COPY public.project (id, created_at, updated_at, deleted_at, kode_project, nama, deskripsi, job_id, jasa_id, tgl_mulai, tgl_selesai, status, harga_penawaran, harga_kesepakatan, users_id, team_id) FROM '$$PATH$$/3138.dat';

--
-- Data for Name: role_has_permissions; Type: TABLE DATA; Schema: public; Owner: laravel
--

COPY public.role_has_permissions (permission_id, role_id) FROM stdin;
\.
COPY public.role_has_permissions (permission_id, role_id) FROM '$$PATH$$/3122.dat';

--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: laravel
--

COPY public.roles (id, name, guard_name, created_at, updated_at) FROM stdin;
\.
COPY public.roles (id, name, guard_name, created_at, updated_at) FROM '$$PATH$$/3119.dat';

--
-- Data for Name: servis; Type: TABLE DATA; Schema: public; Owner: laravel
--

COPY public.servis (id, created_at, updated_at, deleted_at, users_id, jasa_id, kode_servis, merk, model, unit, keterangan, kategori_servis_id, garansi_id, snid, keluhan, status, team_id) FROM stdin;
\.
COPY public.servis (id, created_at, updated_at, deleted_at, users_id, jasa_id, kode_servis, merk, model, unit, keterangan, kategori_servis_id, garansi_id, snid, keluhan, status, team_id) FROM '$$PATH$$/3142.dat';

--
-- Data for Name: supplier; Type: TABLE DATA; Schema: public; Owner: laravel
--

COPY public.supplier (id, created_at, updated_at, deleted_at, nama, alamat, email, telepon, status) FROM stdin;
\.
COPY public.supplier (id, created_at, updated_at, deleted_at, nama, alamat, email, telepon, status) FROM '$$PATH$$/3130.dat';

--
-- Data for Name: team; Type: TABLE DATA; Schema: public; Owner: laravel
--

COPY public.team (id, created_at, updated_at, deleted_at, nik, foto, nama, alamat, email, telepon, dept_id, devisi_id) FROM stdin;
\.
COPY public.team (id, created_at, updated_at, deleted_at, nik, foto, nama, alamat, email, telepon, dept_id, devisi_id) FROM '$$PATH$$/3124.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: laravel
--

COPY public.users (id, name, email, email_verified_at, password, remember_token, created_at, updated_at) FROM stdin;
\.
COPY public.users (id, name, email, email_verified_at, password, remember_token, created_at, updated_at) FROM '$$PATH$$/3112.dat';

--
-- Name: dept_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laravel
--

SELECT pg_catalog.setval('public.dept_id_seq', 1, false);


--
-- Name: devisi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laravel
--

SELECT pg_catalog.setval('public.devisi_id_seq', 1, false);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laravel
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: jasa_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laravel
--

SELECT pg_catalog.setval('public.jasa_id_seq', 1, false);


--
-- Name: job_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laravel
--

SELECT pg_catalog.setval('public.job_id_seq', 1, false);


--
-- Name: kategori_servis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laravel
--

SELECT pg_catalog.setval('public.kategori_servis_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laravel
--

SELECT pg_catalog.setval('public.migrations_id_seq', 24, true);


--
-- Name: part_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laravel
--

SELECT pg_catalog.setval('public.part_id_seq', 1, false);


--
-- Name: part_kategori_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laravel
--

SELECT pg_catalog.setval('public.part_kategori_id_seq', 1, false);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laravel
--

SELECT pg_catalog.setval('public.permissions_id_seq', 8, true);


--
-- Name: post_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laravel
--

SELECT pg_catalog.setval('public.post_id_seq', 1, false);


--
-- Name: project_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laravel
--

SELECT pg_catalog.setval('public.project_id_seq', 1, false);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laravel
--

SELECT pg_catalog.setval('public.roles_id_seq', 1, true);


--
-- Name: servis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laravel
--

SELECT pg_catalog.setval('public.servis_id_seq', 1, false);


--
-- Name: supplier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laravel
--

SELECT pg_catalog.setval('public.supplier_id_seq', 1, false);


--
-- Name: team_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laravel
--

SELECT pg_catalog.setval('public.team_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: laravel
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: dept dept_pkey; Type: CONSTRAINT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.dept
    ADD CONSTRAINT dept_pkey PRIMARY KEY (id);


--
-- Name: devisi devisi_pkey; Type: CONSTRAINT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.devisi
    ADD CONSTRAINT devisi_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: jasa jasa_pkey; Type: CONSTRAINT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.jasa
    ADD CONSTRAINT jasa_pkey PRIMARY KEY (id);


--
-- Name: job job_pkey; Type: CONSTRAINT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.job
    ADD CONSTRAINT job_pkey PRIMARY KEY (id);


--
-- Name: kategori_servis kategori_servis_pkey; Type: CONSTRAINT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.kategori_servis
    ADD CONSTRAINT kategori_servis_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: model_has_permissions model_has_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.model_has_permissions
    ADD CONSTRAINT model_has_permissions_pkey PRIMARY KEY (permission_id, model_id, model_type);


--
-- Name: model_has_roles model_has_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.model_has_roles
    ADD CONSTRAINT model_has_roles_pkey PRIMARY KEY (role_id, model_id, model_type);


--
-- Name: part_kategori part_kategori_pkey; Type: CONSTRAINT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.part_kategori
    ADD CONSTRAINT part_kategori_pkey PRIMARY KEY (id);


--
-- Name: part part_pkey; Type: CONSTRAINT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.part
    ADD CONSTRAINT part_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: post post_pkey; Type: CONSTRAINT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.post
    ADD CONSTRAINT post_pkey PRIMARY KEY (id);


--
-- Name: project project_pkey; Type: CONSTRAINT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_pkey PRIMARY KEY (id);


--
-- Name: role_has_permissions role_has_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_pkey PRIMARY KEY (permission_id, role_id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: servis servis_pkey; Type: CONSTRAINT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.servis
    ADD CONSTRAINT servis_pkey PRIMARY KEY (id);


--
-- Name: supplier supplier_pkey; Type: CONSTRAINT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.supplier
    ADD CONSTRAINT supplier_pkey PRIMARY KEY (id);


--
-- Name: team team_pkey; Type: CONSTRAINT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.team
    ADD CONSTRAINT team_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: model_has_permissions_model_id_model_type_index; Type: INDEX; Schema: public; Owner: laravel
--

CREATE INDEX model_has_permissions_model_id_model_type_index ON public.model_has_permissions USING btree (model_id, model_type);


--
-- Name: model_has_roles_model_id_model_type_index; Type: INDEX; Schema: public; Owner: laravel
--

CREATE INDEX model_has_roles_model_id_model_type_index ON public.model_has_roles USING btree (model_id, model_type);


--
-- Name: password_resets_email_index; Type: INDEX; Schema: public; Owner: laravel
--

CREATE INDEX password_resets_email_index ON public.password_resets USING btree (email);


--
-- Name: model_has_permissions model_has_permissions_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.model_has_permissions
    ADD CONSTRAINT model_has_permissions_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: model_has_roles model_has_roles_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.model_has_roles
    ADD CONSTRAINT model_has_roles_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: role_has_permissions role_has_permissions_permission_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_permission_id_foreign FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_has_permissions role_has_permissions_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: laravel
--

ALTER TABLE ONLY public.role_has_permissions
    ADD CONSTRAINT role_has_permissions_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

